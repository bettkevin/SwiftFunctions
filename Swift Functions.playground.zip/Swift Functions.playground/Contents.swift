import UIKit


var str:String = "Hello, playground"
print(str)
str = "some data"
print(str)

let con = "more data"

//con = 12 constants can't be changed

var b:BooleanLiteralType = true
print (b)
var i:Int = 88
i=45
i=67

var f:Float = 0.67676
//Basic Function
func sayHello(){
    
    print("Hello!")
}
sayHello()
//Function with Parameters
func sayHelloTo(_ name:String,_ age:Int){
    print("Hello \(name), you are \(age) years old")
}
sayHelloTo("Kevin", 30)
//Function with return value

func addFourTo(x:Int) -> Int {
    
    var sum = x + 4
        return sum
}
var result = addFourTo(x: 10)
print(result)





